$(document).ready(function (){
    jQuery(window).load(function () {
        setTimeout(() => {
            $(".main-body").css("visibility", "visible");
            $(".logo-spinner").fadeOut(); 
        }, 1000);            
    });
})
